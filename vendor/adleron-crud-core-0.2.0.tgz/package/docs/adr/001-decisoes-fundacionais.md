# ADR-001 — Decisões fundacionais

Status: **aceito** · Data: 2026-08-30

## Contexto

O `GenericController`/`GenericService` do WorkSafe (e sua cópia no Certfield) resolve CRUD
declarativo bem o suficiente para ter sustentado dois produtos, mas não é extraível: está
soldado ao `PrismaService` local, ao conceito de `companyId`, ao `System_Logs`, ao
`UploadService`/S3, ao `bcrypt` e ao `request.user` do Express. Empacotá-lo como está
distribuiria o acoplamento — e os defeitos.

O Unyo (`unyo-backend`) reescreveu esse núcleo com um manifesto declarativo por entidade
(`defineEntity`) validado no boot. É o desenho certo, e serve de referência. Mas o Unyo
resolveu ficar com Prisma, e nós queremos abrir espaço para outros ORMs.

## Decisões

### D1 — O parser emite IR neutra, não `where` de ORM

O generic atual e o Unyo devolvem `where` no formato Prisma. Para nós isso seria uma
armadilha: o formato vazaria para o serviço, para os hooks e para as regras de entidade, e
"criar um adapter Sequelize" viraria reescrever tudo menos o parser.

O parser produz `FilterNode` (`src/query/filter-ir.ts`). O adapter compila IR → linguagem
do ORM. Nenhuma sintaxe de ORM atravessa uma porta.

**Consequência:** ~20% a mais de trabalho agora; um segundo adapter passa a ser trabalho
localizado em vez de reescrita.

### D2 — Desenhar todas as costuras, implementar um adapter

YAGNI vale para a implementação do Sequelize, não para a interface. `SchemaProvider` e
`Repository` nascem como portas; só o adapter Prisma é implementado. SQL cru fica como
possibilidade, não como meta de v1 — é outro patamar (dialeto, escape, joins).

### D3 — Um pacote, subpaths

`@adleron/crud-core`, `@adleron/crud-core/testing`, e futuramente `/prisma` e `/nestjs`.
Uma versão, um release, sem version skew entre pacotes irmãos. `@nestjs/*`, `@prisma/client`
e `vitest` são peerDependencies **opcionais**.

Dividir em pacotes separados só quando aparecer consumidor que precise de uma parte só.

### D4 — Acoplamento sai por porta, com default seguro

| Porta | Default se não injetada |
|---|---|
| `ScopeResolver` | ausente = single-tenant, sem filtro de escopo |
| `AuditSink` | `noopAuditSink` — quem não injeta, não audita |
| `PermissionChecker` | `denyAllPermissionChecker` — sem checker, rota com permissão não passa |
| `ActorProvider` | ausente = sem ator; quem exige ator lança, nunca inventa id 0 |
| `SchemaProvider` / `Repository` | obrigatórias, vêm do adapter |

O default do `PermissionChecker` é negar de propósito: a lição do generic atual é que
autorização opt-in vira rota aberta esquecida.

### D5 — Contrato de query: híbrido

Medido no `worksafe-front` (pontos de chamada reais):

**Preservado** — `like-` `in-` `not-` `notlike-` `notin-` `gt-` `gte-` `lt-` `lte-` na
chave (~40 usos), `order-<campo>` (~55), `limit`/`limit=all` (72), `page` (6), `show` (13),
`active` (27), filtro aninhado (1) e `-aggregate` (1).

**Cortado** — `omitAttributes` (**0 usos**, vira `maskedFields` declarado no servidor),
`or` em JSON (**1 uso**, vira `or.N.chave`), e o `eval` do fallback de parse.

**Consertado em silêncio** — `notin-` e `notlike-`, quebrados no generic atual por uso de
`includes()` no lugar de `startsWith()` (**0 usos reais**; só apareciam no README do front).

Custo total no front: **um arquivo**. A lib não nasce carregando `omitAttributes`.

### D6 — Base64 não é criptografia

O `encryption.config.ts` do WorkSafe é `Buffer.from(JSON.stringify(v)).toString('base64')`.
Não protege nada e cria a impressão de que protege. Não existe equivalente nesta lib;
campo sensível se resolve com `maskedFields` (omissão) ou criptografia de verdade na
camada de persistência.

### D7 — Violação de filtro nunca é silenciosa

Campo fora da allowlist, operador inaplicável, valor malformado, grupo vazio → sempre
`QueryParseError` com `field` e `reason`. Nenhum caminho devolve filtro parcial. O generic
atual descarta filtro inválido com `console.error` e responde com resultado errado, que é
pior que um erro.

### D8 — Semântica de data preservada de propósito

Data sem horário vira início do dia em `gt`/`gte` e fim do dia em `lt`/`lte`, no fuso local
do servidor — igual ao `processDateValue` do generic atual. Mudar para UTC alteraria o
resultado de todo filtro de período em produção.

## Pendências conhecidas

- `defineEntity` deve rejeitar no boot campo declarado como `filterable` que também esteja
  na lista de chaves reservadas (`active`, `show`, `page`…). O conflito apareceu ao escrever
  os testes do parser e hoje resolve em favor da reserva, em silêncio.
- Adapter Prisma, camada NestJS, serviço de CRUD e auditoria transacional: próximas fatias.
